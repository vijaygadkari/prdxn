<link rel = "stylesheet" href = "css.css">
<script src  = "jquery.js"></script>

<title>jQuery Lightbox !</title>

<body>

<?php

	$images = array("images/1.jpg", "images/2.jpg", "images/3.jpg", "images/4.png");
	
	for($i=0; $i<count($images); $i++){
		echo "<img src = '$images[$i]' style = 'margin: 10px;' width = '150px' onclick = \"display('$images[$i]')\">";
	}

?>

<div id = 'lightbox'>
	
	<div class = 'limage'>
	</div>

	<div class = 'left'>
	</div>
	
	<div class = 'right'>
	</div>
	
	<div class = 'close'>
		X
	</div>
</div>

</body>

<script type = "text/javascript">
		
	function display(src){
		$('.limage').html("<img src = " + src + ">");
		$('#lightbox').css("display", "block");
		$('#lightbox').fadeIn();
		
		
		$('.right').click(function(){ 
			
			var images = <?php echo json_encode($images); ?>;
			var x;
			
			for(x=0; x<<?php echo count($images); ?>-1; x++){
				if(images[x] == src){
					break;
				}
				else{
					continue;
				}
			}
			
			if(x==<?php echo count($images) -1; ?>){
				x=-1;
			}
			
			$('.limage').fadeOut(0);
			$('.limage').html("<img src = " + images[x+1] + " >");
			$('.limage').fadeIn(500);
			src = images[x+1];
		});
		
		$('.left').click(function(){ 
			
			var images = <?php echo json_encode($images); ?>;
			var x;
			
			for(x=0; x<<?php echo count($images); ?>-1; x++){
				if(images[x] == src){
					break;
				}
				else{
					continue;
				}
			}
			
			if(x==0){
				x=<?php echo count($images); ?>;
			}
			
			$('.limage').fadeOut(0);
			$('.limage').html("<img src = " + images[x-1] + " >");
			$('.limage').fadeIn(500);
			src = images[x-1];
		});
		
		$('.close').click(function(){
			$('#lightbox').fadeOut();
		});
		
	}
	
	
	
</script>