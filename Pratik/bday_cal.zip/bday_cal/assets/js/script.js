var myEl = document.getElementById('updateBtn');

//======= Click Event ===============//
myEl.addEventListener('click', function(e) {
		e.preventDefault();
		resetParents('name-list');
    bdayCalender();
}, false);

//======= Reset List Item ===============//
function resetParents(className) {
	$('.'+className).html("");
	// var containerArr = ['sunNameList', 'monNameList'];
	// containerArr.forEach(function(el){
	// 	document.querySelector(el).innerHTML = '';
	// });

}

//======= Birthday calendar function ===============//
function bdayCalender() {

  var jsonData = document.getElementById("myTextArea").value;
  var year = document.getElementById("year").value;
	jsonData = JSON.parse(jsonData);

  jsonData.forEach(function(jsonData) {
  	var fullName = jsonData.name;
    var matches = fullName.match(/\b(\w)/g);
		var acronym = matches.join('');

	  var birthDate = jsonData.birthday;
	  birthDate = new Date(birthDate);
		var currDate =  (birthDate.getMonth() + 1) + "/" + birthDate.getDate() + "/" + year;
		currDate = new Date(currDate);
		var day = currDate.getDay();

		function display_name(id) {
			var objTo = document.getElementById(id);
	    var addList = document.createElement("li");
	    addList.innerHTML = acronym;
	    objTo.appendChild(addList);
		}

		switch (true)
		{
	    case (day == 0):
	   		display_name('sunNameList');
	    	break;
	    case (day == 1):
	   		display_name('monNameList');
	    	break;
	    case (day == 2):
	   		display_name('tueNameList');
	    	break;
	    case (day == 3):
	   		display_name('wedNameList');
	    	break;
	    case (day == 4):
	   		display_name('thuNameList');
	    	break;
	    case (day == 5):
	   		display_name('friNameList');
	    	break;
	    case (day == 6):
	   		display_name('satNameList');
	    	break;
		}

	});
}